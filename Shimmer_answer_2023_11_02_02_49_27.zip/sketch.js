let classifierdemo;
let angel;
function imageReady() {
  image(angel, 0, 0,width,height);
  classifierdemo.predict(angel, gotResults);
}
function gotResults(error, results) {
  if (error) {
    console.log(error);
  } else {
    console.log(results);
  }
}
function setup() {
  createCanvas(400, 400);
  angel = createImg("images/image 29.png",imageReady);
  classifierdemo = ml5.imageClassifier("MobileNet", modelLoaded);
  angel.hide();
}
function modelLoaded() {
  console.log("Ml5 imageClassifer go!!!");
}

function draw() {

}
